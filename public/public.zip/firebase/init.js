var firebaseConfig = {
	apiKey: "AIzaSyCagzEsX8hN4WadTS7_9mCZGwJn3Bwq4yo",
	authDomain: "urgolib.firebaseapp.com",
	databaseURL: "https://urgolib.firebaseio.com",
	projectId: "urgolib",
	storageBucket: "urgolib.appspot.com",
	messagingSenderId: "1020954990339",
	appId: "1:1020954990339:web:5817eea937bc1f5c48fb36",
	measurementId: "G-W0XJN6LXDY"
};

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);